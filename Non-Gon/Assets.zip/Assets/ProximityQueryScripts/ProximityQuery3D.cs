using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using static Utility;

public class ProximityQuery3D : MonoBehaviour
{

    public static bool PointSphere3D(Vector3 positionPoint, Vector3 positionSphere, double sphereRadius)
    {
        double pX = positionPoint.x;
        double pY = positionPoint.y;
        double pZ = positionPoint.z;
        double sX = positionSphere.x;
        double sY = positionSphere.y;
        double sZ = positionSphere.z;

        double distance = Mathf.Sqrt((float)((pX - sX) * (pX - sX) +
                                 (pY - sY) * (pY - sY) +
                                 (pZ - sZ) * (pZ - sZ)));
        return distance < sphereRadius;
    }

    public static bool Point_AABB3D(Vector3 positionPoint, Vector3 positionAABB, double lengthAABB, double heightAABB, double widthAABB)
    {
        double pX = positionPoint.x;
        double pY = positionPoint.y;
        double pZ = positionPoint.z;
        double minX = positionAABB.x - lengthAABB / 2;
        double maxX = positionAABB.x + lengthAABB / 2;
        double minY = positionAABB.y - widthAABB / 2;
        double maxY = positionAABB.y + widthAABB / 2;
        double minZ = positionAABB.z - heightAABB / 2;
        double maxZ = positionAABB.z + heightAABB / 2;

        return (pX >= minX && pX <= maxX) &&
         (pY >= minY && pY <= maxY) &&
         (pZ >= minZ && pZ <= maxZ);
    }

    public static bool Sphere_AABB3D(Vector3 positionAABB, double lengthAABB, double heightAABB, double widthAABB, Vector3 positionSphere, double sphereRadius)
    {
        double minX = positionAABB.x - lengthAABB / 2;
        double maxX = positionAABB.x + lengthAABB / 2;
        double minY = positionAABB.y - widthAABB / 2;
        double maxY = positionAABB.y + widthAABB / 2;
        double minZ = positionAABB.z - heightAABB / 2;
        double maxZ = positionAABB.z + heightAABB / 2;
        double sX = positionSphere.x;
        double sY = positionSphere.y;
        double sZ = positionSphere.z;
        double x = Mathf.Max((float)minX, Mathf.Min((float)sX, (float)maxX));
        double y = Mathf.Max((float)minY, Mathf.Min((float)sY, (float)maxY));
        double z = Mathf.Max((float)minZ, Mathf.Min((float)sZ, (float)maxZ));

        double distance = Mathf.Sqrt((float)((x - sX) * (x - sX) + (y - sY) * (y - sY) + (z - sZ) * (z - sZ)));

        return distance < sphereRadius;
    }

    public static bool SphereSphere3D(Vector3 positionSphere1, Vector3 positionSphere2, double sphereRadius1, double sphereRadius2)
    {

        double sX1 = positionSphere1.x;
        double sX2 = positionSphere2.x;
        double sY1 = positionSphere1.y;
        double sY2 = positionSphere2.y;
        double sZ1 = positionSphere1.z;
        double sZ2 = positionSphere2.z;

        double distance = Mathf.Sqrt((float)((sX1 - sX2) * (sX1 - sX2) +
                                 (sY1 - sY2) * (sY1 - sY2) +
                                 (sZ1 - sZ2) * (sZ1 - sZ2)));
        return distance < (sphereRadius1 + sphereRadius2);
    }

    public static bool AABB_AABB3D(Vector3 positionAABB1, Vector3 positionAABB2, double length1, double length2, double width1, double width2, double heigth1, double heigth2)
    {
        bool res = false;
        double x1 = positionAABB1.x;
        double y1 = positionAABB1.y;
        double x2 = positionAABB2.x;
        double y2 = positionAABB2.y;
        double z1 = positionAABB1.z;
        double z2 = positionAABB2.z;
        if ((x1 < (x2 + length2) && (x1 + length1) > x2) && (y1 < (y2 + width2) && (y1 + width1) > y2) && (z1 < (z2 + heigth2)) && ((z1 + heigth1) > z2))
        {
            res = true;

        }
        return res;
    }

    public static bool OBB_OBB3D(Vector3[] normals, Vector3[] corners1, Vector3[] corners2)
    {
        for (int i = 0; i < normals.Length; i++)
        {
            float shape1Min = 0, shape1Max = 0, shape2Min = 0, shape2Max = 0;
            double[] shape1 = SAT(normals[i], corners1, shape1Min, shape1Max);
            double[] shape2 = SAT(normals[i], corners2, shape2Min, shape2Max);
            if (!Utility.overlaps(shape1[0], shape1[1], shape2[0], shape2[1]))
            {
                return false;
            }
        }
        return true;
    }

    //For different sized boxes
    public static bool AABB_AABB3D_alt(Vector3 position1, Vector3 position2, double l1, double l2, double w1, double w2, double h1, double h2)
    {
        return (position1.x - l1 / 2 <= position2.x + l2 / 2
                && position1.x + l1 / 2 >= position2.x - l2 / 2) &&
                   (position1.y - w1 / 2 <= position2.y + w2 / 2
                && position1.y + w1 / 2 >= position2.y - w2 / 2) &&
                   (position1.z - h1 / 2 <= position2.z + h2 / 2
                && position1.z + h1 / 2 >= position2.z - h2 / 2);
    }

    public static bool Cylinder_Cylinder_Chittawadigi(GameObject Cylinder1, GameObject Cylinder2)
    {
        GeometryCreator variables1 = Cylinder1.GetComponent<GeometryCreator>();
        GeometryCreator variables2 = Cylinder2.GetComponent<GeometryCreator>();
        float yradius1 = variables1.yradius;
        float yradius2 = variables2.yradius;
        // Get the positions and orientations of the cylinders
        Vector3 pos1 = Cylinder1.transform.position;
        Vector3 pos2 = Cylinder2.transform.position;
        Quaternion rot1 = Cylinder1.transform.rotation;
        Quaternion rot2 = Cylinder2.transform.rotation;

        // Calculate the differences in position and rotation
        Vector3 positionDifference = pos2 - pos1;
        Quaternion rotationDifference = Quaternion.Inverse(rot1) * rot2;

        // Extract the individual translation and rotation components
        float theta = Mathf.Atan2(2 * (rotationDifference.y * rotationDifference.z + rotationDifference.w * rotationDifference.x),
                                  1 - 2 * (rotationDifference.x * rotationDifference.x + rotationDifference.y * rotationDifference.y));
        // Create a new axis X^II rotated by theta from X
        Vector3 xAxisII = Quaternion.Euler(0, -theta * Mathf.Rad2Deg, 0) * Vector3.forward;
        float b = Vector3.Dot(positionDifference, xAxisII);


        // Create a new axis X^II rotated by theta from X
        Vector3 xAxisIII = Quaternion.Euler(0, 0, theta * Mathf.Rad2Deg) * Vector3.right;
        float a = Vector3.Dot(positionDifference, xAxisIII);

        // Calculate c as the projection of the position difference onto Z^IV axis
        Vector3 zAxisIV = Quaternion.Euler(0, -theta * Mathf.Rad2Deg, 0) * Vector3.up;
        Vector3 projectedPositionDifference = Vector3.Project(positionDifference, zAxisIV);
        float c = projectedPositionDifference.magnitude;

        // Calculate alpha as the angle between Z^II and Z^III
        float alpha = Mathf.Acos(Vector3.Dot(Vector3.up, zAxisIV));

        // Calculate phi as the difference in rotation around Z^III
        Vector3 xAxisV = Quaternion.Euler(0, 0, alpha * Mathf.Rad2Deg) * Vector3.right;
        float phi = Mathf.Atan2(Vector3.Dot(Vector3.forward, xAxisV), Vector3.Dot(Vector3.up, xAxisV));


        // Display the calculated values
        Debug.Log("Theta: " + theta);
        Debug.Log("b: " + b);
        Debug.Log("a: " + a);
        Debug.Log("Alpha: " + alpha);
        Debug.Log("c: " + c);
        Debug.Log("Phi: " + phi);

        float s1 = yradius1 / 2f;
        float s2 = yradius2 / 2f;

        //Parallel Test
        if ((alpha == 0f || alpha == 180f) & b == 0)
        {
            if (s1 + s2 >= Mathf.Abs(c))
            {
                return true;
            }
            else
            {
                return false;
            }
        }
        else
        {
            //Non Parallel Test
            if (Mathf.Abs(b) <= s1 & Mathf.Abs(c) <= s2)
            {
                return true;
            }
            else
            {
                Vector3 yAxis = Cylinder1.transform.up;
                Vector3 zAxis = Cylinder1.transform.forward;
                // Plane YaZa defined by the axis Y and Z at the center of C1
                Plane YaZa = new Plane(yAxis, Cylinder1.transform.position);
                // Project C1 and C2 onto the YaZa plane resulting in rectangles Q1 and Q2
                Vector3[] Q1Vertices = CalculateRectangleVertices(Cylinder1, YaZa);
                Vector3[] Q2Vertices = CalculateRectangleVertices(Cylinder2, YaZa);

                // Separating Axis Test (SAT) - Check for overlap along each axis of Q1 and Q2
                if (!CheckAxisOverlap(Q1Vertices, Q2Vertices))
                {
                    // No intersection detected by SAT
                    return false;
                }

                // Perform Vertex-Edge Test
                if (!VertexEdgeTest(Q1Vertices, Q2Vertices))
                {
                    // No intersection detected by Vertex-Edge Test
                    return false;
                }

                // Placeholder return (if no further checks are implemented)
                return true;
            }
        }
    }

    // Perform Vertex-Edge Test
    private static bool VertexEdgeTest(Vector3[] vertices1, Vector3[] vertices2)
    {
        for (int i = 0; i < vertices1.Length; i++)
        {
            for (int j = 0; j < 4; j++)
            {
                // Get the endpoints of the edge of vertices2[j]
                Vector3 p1 = vertices2[j];
                Vector3 p2 = vertices2[(j + 1) % 4];

                // Check if vertices1[i] lies on the edge p1-p2
                if (IsPointOnEdge(vertices1[i], p1, p2))
                {
                    // Intersection found, cylinders intersect
                    return true;
                }
            }
        }

        // No intersection found by Vertex-Edge Test
        return false;
    }

    // Function to check if a point (vertex) lies on an edge defined by two points
    private static bool IsPointOnEdge(Vector3 point, Vector3 edgePoint1, Vector3 edgePoint2)
    {
        float distance = Vector3.Distance(edgePoint1, edgePoint2);
        float distance1 = Vector3.Distance(point, edgePoint1);
        float distance2 = Vector3.Distance(point, edgePoint2);

        return Mathf.Approximately(distance, distance1 + distance2);
    }

    // Function to calculate the vertices of the rectangles projected onto the YaZa plane
    private static Vector3[] CalculateRectangleVertices(GameObject cylinder, Plane YaZa)
    {
        Vector3 yAxis = cylinder.transform.up;
        Vector3 zAxis = cylinder.transform.forward;
        Vector3 xAxis = Vector3.Cross(yAxis, zAxis);

        float s = cylinder.GetComponent<GeometryCreator>().yradius / 2f; // Half-height of the cylinder

        // Calculate the vertices of the rectangle projected onto the YaZa plane
        Vector3[] vertices = new Vector3[4];
        vertices[0] = cylinder.transform.position + s * yAxis + s * zAxis;
        vertices[1] = cylinder.transform.position - s * yAxis + s * zAxis;
        vertices[2] = cylinder.transform.position - s * yAxis - s * zAxis;
        vertices[3] = cylinder.transform.position + s * yAxis - s * zAxis;

        for (int i = 0; i < vertices.Length; i++)
        {
            vertices[i] = YaZa.ClosestPointOnPlane(vertices[i]);
        }

        return vertices;
    }

    // Function to check for overlap along each axis of Q1 and Q2
    private static bool CheckAxisOverlap(Vector3[] Q1Vertices, Vector3[] Q2Vertices)
    {
        // Axes of the rectangles (in this case, just edges of the rectangles)
        Vector3[] axes = new Vector3[4];
        for (int i = 0; i < 4; i++)
        {
            axes[i] = Q1Vertices[(i + 1) % 4] - Q1Vertices[i];
            axes[i] = new Vector3(-axes[i].y, axes[i].x, 0f).normalized; // Perpendicular to the edges and in the plane
        }

        // Check for overlap along each axis of Q1 and Q2
        for (int i = 0; i < axes.Length; i++)
        {
            float Q1min, Q1max, Q2min, Q2max;
            ProjectVertices(Q1Vertices, axes[i], out Q1min, out Q1max);
            ProjectVertices(Q2Vertices, axes[i], out Q2min, out Q2max);

            if (!(Q1max >= Q2min && Q2max >= Q1min))
            {
                // No overlap along this axis, hence no intersection
                return false;
            }
        }

        // Overlap along all axes, hence potential intersection
        return true;
    }

    // Function to project vertices onto an axis and find their min and max projections
    private static void ProjectVertices(Vector3[] vertices, Vector3 axis, out float min, out float max)
    {
        min = float.MaxValue;
        max = float.MinValue;

        for (int i = 0; i < vertices.Length; i++)
        {
            float projection = Vector3.Dot(vertices[i], axis);
            if (projection < min)
            {
                min = projection;
            }
            if (projection > max)
            {
                max = projection;
            }
        }
    }


    public static float[] characteristicPolynomialEllipsoid(GameObject Ellipsoid1, GameObject Ellipsoid2)
    {
        GeometryCreator variables1 = Ellipsoid1.GetComponent<GeometryCreator>();
        float xradius1 = variables1.xradius; // Ellipsoid semi axis
        float yradius1 = variables1.yradius;
        float zradius1 = variables1.zradius;
        float xEllipsoid1 = Ellipsoid1.transform.position.x; // Ellipsoid position in space
        float yEllipsoid1 = Ellipsoid1.transform.position.y;
        float zEllipsoid1 = Ellipsoid1.transform.position.z;
        float alpha1 = Utility.getRotationX(Ellipsoid1) * Mathf.Deg2Rad;
        float beta1 = Utility.getRotationY(Ellipsoid1) * Mathf.Deg2Rad;
        float phi1 = Utility.getRotationZ(Ellipsoid1) * Mathf.Deg2Rad;
        GeometryCreator variables2 = Ellipsoid2.GetComponent<GeometryCreator>();
        float xradius2 = variables2.xradius; // Ellipsoid semi axis
        float yradius2 = variables2.yradius;
        float zradius2 = variables2.zradius;
        float xEllipsoid2 = Ellipsoid2.transform.position.x; // Ellipsoid position in space
        float yEllipsoid2 = Ellipsoid2.transform.position.y;
        float zEllipsoid2 = Ellipsoid2.transform.position.z;
        float alpha2 = Utility.getRotationX(Ellipsoid2) * Mathf.Deg2Rad;
        float beta2 = Utility.getRotationY(Ellipsoid2) * Mathf.Deg2Rad;
        float phi2 = Utility.getRotationZ(Ellipsoid2) * Mathf.Deg2Rad;

        float[,] matrixA = new float[4, 4];
        float[,] matrixB = new float[4, 4];

        float aa1 = xradius1 * xradius1;
        float bb1 = yradius1 * yradius1;
        float cc1 = zradius1 * zradius1;

        float aa2 = xradius2 * xradius2;
        float bb2 = yradius2 * yradius2;
        float cc2 = zradius2 * zradius2;

        //Quadric 1
        //x^2
        float A1 = (Mathf.Cos(beta1) * Mathf.Cos(beta1) * Mathf.Cos(phi1) * Mathf.Cos(phi1)) / aa1 + (Mathf.Cos(beta1) * Mathf.Cos(beta1) * Mathf.Sin(phi1) * Mathf.Sin(phi1)) / bb1 +
            (Mathf.Sin(beta1) * Mathf.Sin(beta1)) / cc1;
        //y^2
        float B1 = Mathf.Pow((Mathf.Sin(beta1) * Mathf.Sin(alpha1) * Mathf.Cos(phi1) + Mathf.Sin(phi1) * Mathf.Cos(alpha1)), 2f) / aa1 + Mathf.Pow(Mathf.Sin(phi1) * Mathf.Sin(beta1) * Mathf.Sin(alpha1) + Mathf.Cos(alpha1) * Mathf.Cos(phi1), 2f) / bb1 +
            Mathf.Pow((Mathf.Sin(alpha1) * Mathf.Cos(beta1)), 2f) / cc1;
        //z^2
        float C1 = ((-Mathf.Sin(beta1) * Mathf.Cos(alpha1) * Mathf.Cos(phi1) + Mathf.Sin(alpha1) * Mathf.Sin(phi1)) * (-Mathf.Sin(beta1) * Mathf.Sin(alpha1) * Mathf.Cos(phi1) + Mathf.Sin(alpha1) * Mathf.Sin(phi1))) / aa1 +
            ((Mathf.Sin(beta1) * Mathf.Cos(alpha1) * Mathf.Sin(phi1) + Mathf.Cos(phi1) * Mathf.Sin(alpha1)) * (Mathf.Sin(beta1) * Mathf.Cos(alpha1) * Mathf.Sin(phi1) + Mathf.Cos(phi1) * Mathf.Sin(alpha1))) / bb1 +
            (Mathf.Cos(beta1) * Mathf.Cos(beta1) * Mathf.Cos(alpha1) * Mathf.Cos(alpha1)) / cc1;
        //xy (must divide by 2f)
        float D1 = 2f * ((Mathf.Sin(beta1) * Mathf.Sin(alpha1) * Mathf.Cos(phi1) * Mathf.Cos(beta1) * Mathf.Cos(phi1) + Mathf.Sin(phi1) * Mathf.Cos(alpha1) * Mathf.Cos(beta1) * Mathf.Cos(phi1)) / aa1 +
            (Mathf.Sin(phi1) * Mathf.Sin(beta1) * Mathf.Sin(alpha1) * Mathf.Cos(beta1) * Mathf.Sin(phi1) - Mathf.Cos(alpha1) * Mathf.Cos(phi1) * Mathf.Cos(beta1) * Mathf.Sin(phi1)) / bb1 +
            (-Mathf.Sin(alpha1) * Mathf.Cos(beta1) * Mathf.Sin(beta1)) / cc1);
        //yz (must divide by 2f)
        float E1 = 2f * (((-Mathf.Sin(beta1) * Mathf.Cos(alpha1) * Mathf.Cos(phi1) + Mathf.Sin(alpha1) * Mathf.Sin(phi1)) * (Mathf.Sin(beta1) * Mathf.Sin(alpha1) * Mathf.Cos(phi1) + Mathf.Sin(phi1) * Mathf.Cos(alpha1))) / aa1 +
            ((Mathf.Sin(beta1) * Mathf.Cos(alpha1) * Mathf.Sin(phi1) + Mathf.Cos(phi1) * Mathf.Sin(alpha1)) * (-Mathf.Sin(phi1) * Mathf.Sin(beta1) * Mathf.Sin(alpha1) + Mathf.Cos(alpha1) * Mathf.Cos(phi1))) / bb1 +
            (-Mathf.Cos(beta1) * Mathf.Cos(alpha1) * Mathf.Cos(beta1) * Mathf.Sin(alpha1)) / cc1);
        //zx (must divide by 2f)
        float F1 = 2f * ((-Mathf.Sin(beta1) * Mathf.Cos(alpha1) * Mathf.Cos(phi1) * Mathf.Cos(beta1) * Mathf.Cos(phi1) + Mathf.Sin(alpha1) * Mathf.Sin(phi1) * Mathf.Cos(beta1) * Mathf.Cos(phi1)) / aa1 +
            (-Mathf.Sin(beta1) + Mathf.Cos(alpha1) * Mathf.Sin(phi1) * Mathf.Cos(beta1) * Mathf.Sin(phi1) - Mathf.Cos(phi1) * Mathf.Sin(alpha1) * Mathf.Cos(beta1) * Mathf.Sin(phi1)) / bb1 +
            (Mathf.Cos(beta1) * Mathf.Cos(alpha1) * Mathf.Sin(beta1)) / cc1);
        //x (must divide by 2f)
        float G1 = (-2f * xEllipsoid1 * A1) + (-yEllipsoid1 * D1) + (-zEllipsoid1 * F1);
        //y (must divide by 2f)
        float H1 = (-xEllipsoid1 * D1) + (-2f * yEllipsoid1 * B1) + (-zEllipsoid1 * E1);
        //z (must divide by 2f)
        float I1 = (-xEllipsoid1 * F1) + (-yEllipsoid1 * E1) + (-2f * zEllipsoid1 * C1);
        //independent
        float J1 = (xEllipsoid1 * xEllipsoid1 * A1) + (xEllipsoid1 * yEllipsoid1 * D1) + (xEllipsoid1 * zEllipsoid1 * F1) + (yEllipsoid1 * yEllipsoid1 * B1) +
            (yEllipsoid1 * zEllipsoid1 * E1) + (zEllipsoid1 * zEllipsoid1 * C1);

        matrixA[0, 0] = A1;
        matrixA[0, 1] = D1 / 2f;
        matrixA[0, 2] = F1 / 2f;
        matrixA[0, 3] = G1 / 2f;
        matrixA[1, 0] = D1 / 2f;
        matrixA[1, 1] = B1;
        matrixA[1, 2] = E1 / 2f;
        matrixA[1, 3] = H1 / 2f;
        matrixA[2, 0] = F1 / 2f;
        matrixA[2, 1] = E1 / 2f;
        matrixA[2, 2] = C1;
        matrixA[2, 3] = I1 / 2f;
        matrixA[3, 0] = G1 / 2f;
        matrixA[3, 1] = H1 / 2f;
        matrixA[3, 2] = I1 / 2f;
        matrixA[3, 3] = J1;


        //Quadric 1
        //x^2
        float A2 = (Mathf.Cos(beta2) * Mathf.Cos(beta2) * Mathf.Cos(phi2) * Mathf.Cos(phi2)) / aa2 + (Mathf.Cos(beta2) * Mathf.Cos(beta2) * Mathf.Sin(phi2) * Mathf.Sin(phi2)) / bb2 +
            (Mathf.Sin(beta2) * Mathf.Sin(beta2)) / cc2;
        //y^2
        float B2 = Mathf.Pow((Mathf.Sin(beta2) * Mathf.Sin(alpha2) * Mathf.Cos(phi2) + Mathf.Sin(phi2) * Mathf.Cos(alpha2)), 2f) / aa2 + Mathf.Pow(Mathf.Sin(phi2) * Mathf.Sin(beta2) * Mathf.Sin(alpha2) + Mathf.Cos(alpha2) * Mathf.Cos(phi2), 2f) / bb2 +
            Mathf.Pow((Mathf.Sin(alpha2) * Mathf.Cos(beta2)), 2f) / cc2;
        //z^2
        float C2 = ((-Mathf.Sin(beta2) * Mathf.Cos(alpha2) * Mathf.Cos(phi2) + Mathf.Sin(alpha2) * Mathf.Sin(phi2)) * (-Mathf.Sin(beta2) * Mathf.Sin(alpha2) * Mathf.Cos(phi2) + Mathf.Sin(alpha2) * Mathf.Sin(phi2))) / aa2 +
            ((Mathf.Sin(beta2) * Mathf.Cos(alpha2) * Mathf.Sin(phi2) + Mathf.Cos(phi2) * Mathf.Sin(alpha2)) * (Mathf.Sin(beta2) * Mathf.Cos(alpha2) * Mathf.Sin(phi2) + Mathf.Cos(phi2) * Mathf.Sin(alpha2))) / bb2 +
            (Mathf.Cos(beta2) * Mathf.Cos(beta2) * Mathf.Cos(alpha2) * Mathf.Cos(alpha2)) / cc2;
        //xy (must divide by 2f)
        float D2 = 2f * ((Mathf.Sin(beta2) * Mathf.Sin(alpha2) * Mathf.Cos(phi2) * Mathf.Cos(beta2) * Mathf.Cos(phi2) + Mathf.Sin(phi2) * Mathf.Cos(alpha2) * Mathf.Cos(beta2) * Mathf.Cos(phi2)) / aa2 +
            (Mathf.Sin(phi2) * Mathf.Sin(beta2) * Mathf.Sin(alpha2) * Mathf.Cos(beta2) * Mathf.Sin(phi2) - Mathf.Cos(alpha2) * Mathf.Cos(phi2) * Mathf.Cos(beta2) * Mathf.Sin(phi2)) / bb2 +
            (-Mathf.Sin(alpha2) * Mathf.Cos(beta2) * Mathf.Sin(beta2)) / cc2);
        //yz (must divide by 2f)
        float E2 = 2f * (((-Mathf.Sin(beta2) * Mathf.Cos(alpha2) * Mathf.Cos(phi2) + Mathf.Sin(alpha2) * Mathf.Sin(phi2)) * (Mathf.Sin(beta2) * Mathf.Sin(alpha2) * Mathf.Cos(phi2) + Mathf.Sin(phi2) * Mathf.Cos(alpha2))) / aa2 +
            ((Mathf.Sin(beta2) * Mathf.Cos(alpha2) * Mathf.Sin(phi2) + Mathf.Cos(phi2) * Mathf.Sin(alpha2)) * (-Mathf.Sin(phi2) * Mathf.Sin(beta2) * Mathf.Sin(alpha2) + Mathf.Cos(alpha2) * Mathf.Cos(phi2))) / bb2 +
            (-Mathf.Cos(beta2) * Mathf.Cos(alpha2) * Mathf.Cos(beta2) * Mathf.Sin(alpha2)) / cc2);
        //zx (must divide by 2f)
        float F2 = 2f * ((-Mathf.Sin(beta2) * Mathf.Cos(alpha2) * Mathf.Cos(phi2) * Mathf.Cos(beta2) * Mathf.Cos(phi2) + Mathf.Sin(alpha2) * Mathf.Sin(phi2) * Mathf.Cos(beta2) * Mathf.Cos(phi2)) / aa2 +
            (-Mathf.Sin(beta2) + Mathf.Cos(alpha2) * Mathf.Sin(phi2) * Mathf.Cos(beta2) * Mathf.Sin(phi2) - Mathf.Cos(phi2) * Mathf.Sin(alpha2) * Mathf.Cos(beta2) * Mathf.Sin(phi2)) / bb2 +
            (Mathf.Cos(beta2) * Mathf.Cos(alpha2) * Mathf.Sin(beta2)) / cc2);
        //x (must divide by 2f)
        float G2 = (-2f * xEllipsoid2 * A2) + (-yEllipsoid2 * D2) + (-zEllipsoid2 * F2);
        //y (must divide by 2f)
        float H2 = (-xEllipsoid2 * D2) + (-2f * yEllipsoid2 * B2) + (-zEllipsoid2 * E2);
        //z (must divide by 2f)
        float I2 = (-xEllipsoid2 * F2) + (-yEllipsoid2 * E2) + (-2f * zEllipsoid2 * C2);
        //independent
        float J2 = (xEllipsoid2 * xEllipsoid2 * A2) + (xEllipsoid2 * yEllipsoid2 * D2) + (xEllipsoid2 * zEllipsoid2 * F2) + (yEllipsoid2 * yEllipsoid2 * B2) +
            (yEllipsoid2 * zEllipsoid2 * E2) + (zEllipsoid2 * zEllipsoid2 * C2);

        matrixB[0, 0] = A2;
        matrixB[0, 1] = D2 / 2f;
        matrixB[0, 2] = F2 / 2f;
        matrixB[0, 3] = G2 / 2f;
        matrixB[1, 0] = D2 / 2f;
        matrixB[1, 1] = B2;
        matrixB[1, 2] = E2 / 2f;
        matrixB[1, 3] = H2 / 2f;
        matrixB[2, 0] = F2 / 2f;
        matrixB[2, 1] = E2 / 2f;
        matrixB[2, 2] = C2;
        matrixB[2, 3] = I2 / 2f;
        matrixB[3, 0] = G2 / 2f;
        matrixB[3, 1] = H2 / 2f;
        matrixB[3, 2] = I2 / 2f;
        matrixB[3, 3] = J2;

        float a4 = Utility.calDetMatrix4x4(matrixA);
        float a3 = (A1 * B1 * C1 * J2 + A1 * B1 * C2 * J1 + A1 * B2 * C1 * J1 + A2 * B1 * C1 * J1) +
            (A1 * E1 * I1 * H2 + A1 * E1 * I2 * H1 + A1 * E2 * I1 * H1 + A2 * E1 * I1 * H1) +
            (A1 * H1 * E1 * I2 + A1 * H1 * E2 * I1 + A1 * H2 * E1 * I1 + A2 * H1 * E1 * I1) -
            (A1 * H1 * C1 * H2 + A1 * H1 * C2 * H1 + A1 * H2 * C1 * H1 + A2 * H1 * C1 * H1) -
            (A1 * E1 * E1 * J2 + A1 * E1 * E2 * J1 + A1 * E2 * E1 * J1 + A2 * E1 * E1 * J1) -
            (A1 * B1 * I1 * I2 + A1 * B1 * I2 * I1 + A1 * B2 * I1 * I1 + A2 * B1 * I1 * I1) -
            (D1 * D1 * C1 * J2 + D1 * D1 * C2 * J1 + D1 * D2 * C1 * J1 + D2 * D1 * C1 * J1) -
            (F1 * D1 * I1 * H2 + F1 * D1 * I2 * H1 + F1 * D2 * I1 * H1 + F2 * D1 * I1 * H1) -
            (G1 * D1 * E1 * I2 + G1 * D1 * E2 * I1 + G1 * D2 * E1 * I1 + G2 * D1 * E1 * I1) +
            (G1 * D1 * C1 * H2 + G1 * D1 * C2 * H1 + G1 * D2 * C1 * H1 + G2 * D1 * C1 * H1) +
            (F1 * D1 * E1 * J2 + F1 * D1 * E2 * J1 + F1 * D2 * E1 * J1 + F2 * D1 * E1 * J1) +
            (D1 * D1 * I1 * I2 + D1 * D1 * I2 * I1 + D1 * D2 * I1 * I1 + D2 * D1 * I1 * I1) +
            (D1 * E1 * F1 * J2 + D1 * E1 * F2 * J1 + D1 * E2 * F1 * J1 + D2 * E1 * F1 * J1) +
            (F1 * H1 * F1 * H2 + F1 * H1 * F2 * H1 + F1 * H2 * F1 * H1 + F2 * H1 * F1 * H1) +
            (G1 * B1 * F1 * I2 + G1 * B1 * F2 * I1 + G1 * B2 * F1 * I1 + G2 * B1 * F1 * I1) -
            (G1 * E1 * F1 * H2 + G1 * E1 * F2 * H1 + G1 * E2 * F1 * H1 + G2 * E1 * F1 * H1) -
            (F1 * B1 * F1 * J2 + F1 * B1 * F2 * J1 + F1 * B2 * F1 * J1 + F2 * B1 * F1 * J1) -
            (D1 * H1 * F1 * I2 + D1 * H1 * F2 * I1 + D1 * H2 * F1 * I1 + D2 * H1 * F1 * I1) -
            (D1 * E1 * I1 * G2 + D1 * E1 * I2 * G1 + D1 * E2 * I1 * G1 + D2 * E1 * I1 * G1) -
            (F1 * H1 * E1 * G2 + F1 * H1 * E2 * G1 + F1 * H2 * E1 * G1 + F2 * H1 * E1 * G1) -
            (G1 * B1 * C1 * G2 + G1 * B1 * C2 * G1 + G1 * B2 * C1 * G1 + G2 * B1 * C1 * G1) +
            (G1 * E1 * E1 * G2 + G1 * E1 * E2 * G1 + G1 * E2 * E1 * G1 + G2 * E1 * E1 * G1) +
            (F1 * B1 * I1 * G2 + F1 * B1 * I2 * G1 + F1 * B2 * I1 * G1 + F2 * B1 * I1 * G1) +
            (D1 * H1 * C1 * G2 + D1 * H1 * C2 * G1 + D1 * H2 * C1 * G1 + D2 * H1 * C1 * G1);
        float a2 = (A1 * B1 * C2 * J2 + A1 * B2 * C1 * J2 + A1 * B2 * C2 * J1 + A2 * B1 * C1 * J2 + A2 * B1 * C2 * J1 + A2 * B2 * C1 * J1) +
            (A1 * E1 * I2 * H2 + A1 * E2 * I1 * H2 + A1 * E2 * I2 * H1 + A2 * E1 * I1 * H2 + A2 * E1 * I2 * H1 + A2 * E2 * I1 * H1) +
            (A1 * H1 * E2 * I2 + A1 * H2 * E1 * I2 + A1 * H2 * E2 * I1 + A2 * H1 * E1 * I2 + A2 * H1 * E2 * I1 + A2 * H2 * E1 * I1) -
            (A1 * H1 * C2 * H2 + A1 * H2 * C1 * H2 + A1 * H2 * C2 * H1 + A2 * H1 * C1 * H2 + A2 * H1 * C2 * H1 + A2 * H2 * C1 * H1) -
            (A1 * E1 * E2 * J2 + A1 * E2 * E1 * J2 + A1 * E2 * E2 * J1 + A2 * E1 * E1 * J2 + A2 * E1 * E2 * J1 + A2 * E2 * E1 * J1) -
            (A1 * B1 * I2 * I2 + A1 * B2 * I1 * I2 + A1 * B2 * I2 * I1 + A2 * B1 * I1 * I2 + A2 * B1 * I2 * I1 + A2 * B2 * I1 * I1) -
            (D1 * D1 * C2 * J2 + D1 * D2 * C1 * J2 + D1 * D2 * C2 * J1 + D2 * D1 * C1 * J2 + D2 * D1 * C2 * J1 + D2 * D2 * C1 * J1) -
            (F1 * D1 * I2 * H2 + F1 * D2 * I1 * H2 + F1 * D2 * I2 * H1 + F2 * D1 * I1 * H2 + F2 * D1 * I2 * H1 + F2 * D2 * I1 * H1) -
            (G1 * D1 * E2 * I2 + G1 * D2 * E1 * I2 + G1 * D2 * E2 * I1 + G2 * D1 * E1 * I2 + G2 * D1 * E2 * I1 + G2 * D2 * E1 * I1) +
            (G1 * D1 * C2 * H2 + G1 * D2 * C1 * H2 + G1 * D2 * C2 * H1 + G2 * D1 * C1 * H2 + G2 * D1 * C2 * H1 + G2 * D2 * C1 * H1) +
            (F1 * D1 * E2 * J2 + F1 * D2 * E1 * J2 + F1 * D2 * E2 * J1 + F2 * D1 * E1 * J2 + F2 * D1 * E2 * J1 + F2 * D2 * E1 * J1) +
            (D1 * D1 * I2 * I2 + D1 * D2 * I1 * I2 + D1 * D2 * I2 * I1 + D2 * D1 * I1 * I2 + D2 * D1 * I2 * I1 + D2 * D2 * I1 * I1) +
            (D1 * E1 * F2 * J2 + D1 * E2 * F1 * J2 + D1 * E2 * F2 * J1 + D2 * E1 * F1 * J2 + D2 * E1 * F2 * J1 + D2 * E2 * F1 * J1) +
            (F1 * H1 * F2 * H2 + F1 * H2 * F1 * H2 + F1 * H2 * F2 * H1 + F2 * H1 * F1 * H2 + F2 * H1 * F2 * H1 + F2 * H2 * F1 * H1) +
            (G1 * B1 * F2 * I2 + G1 * B2 * F1 * I2 + G1 * B2 * F2 * I1 + G2 * B1 * F1 * I2 + G2 * B1 * F2 * I1 + G2 * B2 * F1 * I1) -
            (G1 * E1 * F2 * H2 + G1 * E2 * F1 * H2 + G1 * E2 * F2 * H1 + G2 * E1 * F1 * H2 + G2 * E1 * F2 * H1 + G2 * E2 * F1 * H1) -
            (F1 * B1 * F2 * J2 + F1 * B2 * F1 * J2 + F1 * B2 * F2 * J1 + F2 * B1 * F1 * J2 + F2 * B1 * F2 * J1 + F2 * B2 * F1 * J1) -
            (D1 * H1 * F2 * I2 + D1 * H2 * F1 * I2 + D1 * H2 * F2 * I1 + D2 * H1 * F1 * I2 + D2 * H1 * F2 * I1 + D2 * H2 * F1 * I1) -
            (D1 * E1 * I2 * G2 + D1 * E2 * I1 * G2 + D1 * E2 * I2 * G1 + D2 * E1 * I1 * G2 + D2 * E1 * I2 * G1 + D2 * E2 * I1 * G1) -
            (F1 * H1 * E2 * G2 + F1 * H2 * E1 * G2 + F1 * H2 * E2 * G1 + F2 * H1 * E1 * G2 + F2 * H1 * E2 * G1 + F2 * H2 * E1 * G1) -
            (G1 * B1 * C2 * G2 + G1 * B2 * C1 * G2 + G1 * B2 * C2 * G1 + G2 * B1 * C1 * G2 + G2 * B1 * C2 * G1 + G2 * B2 * C1 * G1) +
            (G1 * E1 * E2 * G2 + G1 * E2 * E1 * G2 + G1 * E2 * E2 * G1 + G2 * E1 * E1 * G2 + G2 * E1 * E2 * G1 + G2 * E2 * E1 * G1) +
            (F1 * B1 * I2 * G2 + F1 * B2 * I1 * G2 + F1 * B2 * I2 * G1 + F2 * B1 * I1 * G2 + F2 * B1 * I2 * G1 + F2 * B2 * I1 * G1) +
            (D1 * H1 * C2 * G2 + D1 * H2 * C1 * G2 + D1 * H2 * C2 * G1 + D2 * H1 * C1 * G2 + D2 * H1 * C2 * G1 + D2 * H2 * C1 * G1);
        float a1 = (A1 * B2 * C2 * J2 + A2 * B1 * C2 * J2 + A2 * B2 * C1 * J2 + A2 * B2 * C2 * J1) +
            (A1 * E2 * I2 * H2 + A2 * E1 * I2 * H2 + A2 * E2 * I1 * H2 + A2 * E2 * I2 * H1) +
            (A1 * H2 * E2 * I2 + A2 * H1 * E2 * I2 + A2 * H2 * E1 * I2 + A2 * H2 * E2 * I1) -
            (A1 * H2 * C2 * H2 + A2 * H1 * C2 * H2 + A2 * H2 * C1 * H2 + A2 * H2 * C2 * H1) -
            (A1 * E2 * E2 * J2 + A2 * E1 * E2 * J2 + A2 * E2 * E1 * J2 + A2 * E2 * E2 * J1) -
            (A1 * B2 * I2 * I2 + A2 * B1 * I2 * I2 + A2 * B2 * I1 * I2 + A2 * B2 * I2 * I1) -
            (D1 * D2 * C2 * J2 + D2 * D1 * C2 * J2 + D2 * D2 * C1 * J2 + D2 * D2 * C2 * J1) -
            (F1 * D2 * I2 * H2 + F2 * D1 * I2 * H2 + F2 * D2 * I1 * H2 + F2 * D2 * I2 * H1) -
            (G1 * D2 * E2 * I2 + G2 * D1 * E2 * I2 + G2 * D2 * E1 * I2 + G2 * D2 * E2 * I1) +
            (G1 * D2 * C2 * H2 + G2 * D1 * C2 * H2 + G2 * D2 * C1 * H2 + G2 * D2 * C2 * H1) +
            (F1 * D2 * E2 * J2 + F2 * D1 * E2 * J2 + F2 * D2 * E1 * J2 + F2 * D2 * E2 * J1) +
            (D1 * D2 * I2 * I2 + D2 * D1 * I2 * I2 + D2 * D2 * I1 * I2 + D2 * D2 * I2 * I1) +
            (D1 * E2 * F2 * J2 + D2 * E1 * F2 * J2 + D2 * E2 * F1 * J2 + D2 * E2 * F2 * J1) +
            (F1 * H2 * F2 * H2 + F2 * H1 * F2 * H2 + F2 * H2 * F1 * H2 + F2 * H2 * F2 * H1) +
            (G1 * B2 * F2 * I2 + G2 * B1 * F2 * I2 + G2 * B2 * F1 * I2 + G2 * B2 * F2 * I1) -
            (G1 * E2 * F2 * H2 + G2 * E1 * F2 * H2 + G2 * E2 * F1 * H2 + G2 * E2 * F2 * H1) -
            (F1 * B2 * F2 * J2 + F2 * B1 * F2 * J2 + F2 * B2 * F1 * J2 + F2 * B2 * F2 * J1) -
            (D1 * H2 * F2 * I2 + D2 * H1 * F2 * I2 + D2 * H2 * F1 * I2 + D2 * H2 * F2 * I1) -
            (D1 * E2 * I2 * G2 + D2 * E1 * I2 * G2 + D2 * E2 * I1 * G2 + D2 * E2 * I2 * G1) -
            (F1 * H2 * E2 * G2 + F2 * H1 * E2 * G2 + F2 * H2 * E1 * G2 + F2 * H2 * E2 * G1) -
            (G1 * B2 * C2 * G2 + G2 * B1 * C2 * G2 + G2 * B2 * C1 * G2 + G2 * B2 * C2 * G1) +
            (G1 * E2 * E2 * G2 + G2 * E1 * E2 * G2 + G2 * E2 * E1 * G2 + G2 * E2 * E2 * G1) +
            (F1 * B2 * I2 * G2 + F2 * B1 * I2 * G2 + F2 * B2 * I1 * G2 + F2 * B2 * I2 * G1) +
            (D1 * H2 * C2 * G2 + D2 * H1 * C2 * G2 + D2 * H2 * C1 * G2 + D2 * H2 * C2 * G1);
        float a0 = Utility.calDetMatrix4x4(matrixB);

        return new float[5] { a4, a3, a2, a1, a0 };
    }

    public static bool Ellipsoid_Ellipsoid_Caravantes(GameObject Ellipsoid1, GameObject Ellipsoid2)
    {
        float[] characteristicPolynomialValues = characteristicPolynomialEllipsoid(Ellipsoid1, Ellipsoid2);

        float a4 = characteristicPolynomialValues[0];
        float a3 = characteristicPolynomialValues[1];
        float a2 = characteristicPolynomialValues[2];
        float a1 = characteristicPolynomialValues[3];
        float a0 = characteristicPolynomialValues[4];

        Debug.Log("--------------------");

        foreach (float a in Utility.quartic_roots_(a4, a3, a2, a1, a0))
        {
            Debug.Log(a);
        }

        float s0 = a4 * (256f * a0 * a0 * a0 * a4 * a4 * a4 - 192f * a0 * a0 * a1 * a3 * a4 * a4 - 128f * a0 * a0 * a2 * a2 * a4 * a4 + 144f * a0 * a0 *
            a2 * a3 * a3 * a4 - 27f * a0 * a0 * a3 * a3 * a3 * a3 + 144f * a0 * a1 * a1 * a2 * a4 * a4 - 6f * a0 * a1 * a1 * a3 * a3 * a4 - 80f * a0 *
            a1 * a2 * a2 * a3 * a4 + 18f * a0 * a1 * a2 * a3 * a3 * a3 + 16f * a0 * a2 * a2 * a2 * a2 * a4 - 4f * a0 * a2 * a2 * a2 * a3 * a3 - 27f * a1
            * a1 * a1 * a1 * a4 * a4 + 18f * a1 * a1 * a1 * a2 * a3 * a4 - 4f * a1 * a1 * a1 * a3 * a3 * a3 - 4f * a1 * a1 * a2 * a2 * a2 * a4 + a1 * a1
            * a2 * a2 * a3 * a3);
        float s1 = 2 * a4 * (16f * a0 * a2 * a4 * a4 - 6f * a0 * a3 * a3 * a4 - 18f * a1 * a1 * a4 * a4 + 14f * a1 * a2 * a3 * a4 - 3f * a1 * a3 * a3 *
            a3 - 4f * a2 * a2 * a2 * a4 + a2 * a2 * a3 * a3);
        float s10 = -a4 * (48f * a0 * a1 * a4 * a4 - 32f * a0 * a2 * a3 * a4 + 9f * a0 * a3 * a3 * a3 - 3f * a1 * a1 * a3 * a4 + 4f * a1 * a2 * a2 * a4
            - a1 * a2 * a3 * a3);

        if (s0 == 0f & s1 < 0f & s10 < 0f)
        {
            if (a3 > 0f & a2 > 0f)
            {
                return false;
            }
            else if (a3 > 0f & a2 < 0f & a1 < 0f)
            {
                return false;
            }
            else if (a3 < 0f & a2 > 0f)
            {
                return false;
            }
            else if (a3 < 0f & a2 < 0f & a1 > 0f)
            {
                return false;
            }
        }
        if (s0 < 0f)
        {
            if (a3 > 0f & a2 > 0f)
            {
                return false;
            }
            else if (a3 > 0f & a2 < 0f & a1 < 0f)
            {
                return false;
            }
            else if (a3 < 0f & a2 > 0f)
            {
                return false;
            }
            else if (a3 < 0f & a2 < 0f & a1 > 0f)
            {
                return false;
            }
        }
        return true;
    }

    public static bool Ellipsoid_EllipticParaboloid_Brozos(GameObject Ellipsoid1, GameObject EllipticParaboloid)
    {

        float[] characteristicPolynomialValues = characteristicPolynomialEllipsoid(Ellipsoid1, EllipticParaboloid);

        float a4 = characteristicPolynomialValues[0];
        float a3 = characteristicPolynomialValues[1];
        float a2 = characteristicPolynomialValues[2];
        float a1 = characteristicPolynomialValues[3];
        float a0 = characteristicPolynomialValues[4];

        float discriminant = (256f * a0 * a0 * a0 * a4 * a4 * a4 - 192f * a0 * a0 * a1 * a3 * a4 * a4 - 128f * a0 * a0 * a2 * a2 * a4 * a4 + 144f * a0 * a0 *
            a2 * a3 * a3 * a4 - 27f * a0 * a0 * a3 * a3 * a3 * a3 + 144f * a0 * a1 * a1 * a2 * a4 * a4 - 6f * a0 * a1 * a1 * a3 * a3 * a4 - 80f * a0 *
            a1 * a2 * a2 * a3 * a4 + 18f * a0 * a1 * a2 * a3 * a3 * a3 + 16f * a0 * a2 * a2 * a2 * a2 * a4 - 4f * a0 * a2 * a2 * a2 * a3 * a3 - 27f * a1
            * a1 * a1 * a1 * a4 * a4 + 18f * a1 * a1 * a1 * a2 * a3 * a4 - 4f * a1 * a1 * a1 * a3 * a3 * a3 - 4f * a1 * a1 * a2 * a2 * a2 * a4 + a1 * a1
            * a2 * a2 * a3 * a3);

        if (discriminant < 0)
        {
            return true;
        }
        return false;
    }

    public static bool Ellipsoid_Quadric_Brozos(GameObject Ellipsoid1, GameObject Quadric)
    {
        float[] characteristicPolynomialValues = characteristicPolynomialEllipsoid(Ellipsoid1, Quadric);

        float a4 = characteristicPolynomialValues[0];
        float a3 = characteristicPolynomialValues[1];
        float a2 = characteristicPolynomialValues[2];
        float a1 = characteristicPolynomialValues[3];
        float a0 = characteristicPolynomialValues[4];

        float discriminant4 = (256f * a0 * a0 * a0 * a4 * a4 * a4 - 192f * a0 * a0 * a1 * a3 * a4 * a4 - 128f * a0 * a0 * a2 * a2 * a4 * a4 + 144f * a0 * a0 *
            a2 * a3 * a3 * a4 - 27f * a0 * a0 * a3 * a3 * a3 * a3 + 144f * a0 * a1 * a1 * a2 * a4 * a4 - 6f * a0 * a1 * a1 * a3 * a3 * a4 - 80f * a0 *
            a1 * a2 * a2 * a3 * a4 + 18f * a0 * a1 * a2 * a3 * a3 * a3 + 16f * a0 * a2 * a2 * a2 * a2 * a4 - 4f * a0 * a2 * a2 * a2 * a3 * a3 - 27f * a1
            * a1 * a1 * a1 * a4 * a4 + 18f * a1 * a1 * a1 * a2 * a3 * a4 - 4f * a1 * a1 * a1 * a3 * a3 * a3 - 4f * a1 * a1 * a2 * a2 * a2 * a4 + a1 * a1
            * a2 * a2 * a3 * a3);
        float discriminant3 = (16f * a0 * a2 * a4 * a4 - 6f * a0 * a3 * a3 * a4 - 18f * a1 * a1 * a4 * a4 + 14f * a1 * a2 * a3 * a4 - 3f * a1 * a3 * a3 *
            a3 - 4f * a2 * a2 * a2 * a4 + a2 * a2 * a3 * a3);

        string zone = "";
        if (discriminant3 < 0)
        {
            zone = "Zone0";
        }
        else
        {
            if (a3 > 0)
            {
                zone = "Zone1";
            }
            else
            {
                zone = "Zone2";
            }
        }
        if (string.Compare(zone, "Zone1") == 0)
        {
            if ((discriminant4 < 0) || (discriminant4 == 0 & discriminant3 < 0))
            {

            }
        }
        else if (string.Compare(zone, "Zone2") == 0)
        {

        }
        return false;
    }

    public static bool Hyperboloid_Plane_Bektas(GameObject Hyperboloid, GameObject Plane)
    {
        // Get the GameObject's mesh
        Mesh mesh = Plane.GetComponent<MeshFilter>().mesh;

        Debug.Log(mesh.vertices.Length);
        // Get three vertices from the mesh (assuming the mesh is a flat surface)
        Vector3 vertex1 = mesh.vertices[0];
        Vector3 vertex2 = mesh.vertices[50];
        Vector3 vertex3 = mesh.vertices[100];

        // Calculate normal to the plane using the cross product of two edge vectors
        Vector3 edge1 = vertex2 - vertex1;
        Vector3 edge2 = vertex3 - vertex1;
        Vector3 normal = Vector3.Cross(edge1, edge2).normalized;

        // Extracting coefficients of the plane equation
        float Ax = normal.x;
        float Ay = normal.y;
        float Az = normal.z;
        float Ad = -Vector3.Dot(normal, vertex1);

        // Output the coefficients
        Debug.Log("Coefficients of the plane equation: ");
        Debug.Log("Ax: " + Ax);
        Debug.Log("Ay: " + Ay);
        Debug.Log("Az: " + Az);
        Debug.Log("Ad: " + Ad);

        return false;
    }
}
