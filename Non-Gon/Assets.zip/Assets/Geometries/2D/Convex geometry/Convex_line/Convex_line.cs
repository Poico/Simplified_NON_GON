using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Convex_line : MonoBehaviour
{

    public static float f (float alpha)
    {
        float res;
        if(alpha >= -Mathf.PI/2f & alpha <= Mathf.PI/2f)
        {
            res = 10f*(1f + 0.9f*Mathf.Cos(alpha - 0.2f*Mathf.PI) + 1f/6f*Mathf.Sin(2f*(alpha - 0.2f*Mathf.PI)) + 1f/15f*Mathf.Sin(3f*(alpha - 0.2f*Mathf.PI)));
        }
        else
        {
            res = 0f;
            
        }
        return res;
    }

    public static float fd (float alpha)
    {
        float res;
        if(alpha >= -Mathf.PI/2f & alpha <= Mathf.PI/2f)
        {
            res = 10f*(-0.9f*Mathf.Sin(alpha - 0.2f*Mathf.PI) + 1f/3f*Mathf.Cos(2*(alpha - 0.2f*Mathf.PI)) + 0.2f*Mathf.Cos(3f*(alpha - 0.2f*Mathf.PI)));
        }
        else
        {
            res = 0f;
            
        }
        return res;
    }

    public static Vector2 point(float angle)
    {
        float r = Mathf.Sqrt(Mathf.Pow(f(angle),2f) + Mathf.Pow(fd(angle),2f));
        float phi = angle + Mathf.Atan2(fd(angle),f(angle)) - Mathf.PI/2f;
        Vector2 pos = new Vector2(Mathf.Cos(phi), Mathf.Sin(phi));
        return pos * r;
    }
}
