using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using static Minimum_distance_2D;
using static Minimum_distance_3D;
using static ProximityQuery2D;
using static ProximityQuery3D;
using static Utility;

public class SceneUpdate : MonoBehaviour
{
    public bool isMinimumDistance;
    public bool is2D;
    public bool collision;
    public GameObject obj1;
    public GameObject obj2;
    public GameObject connect; //distance visualizer
    
    LineRenderer line;

    // Start is called before the first frame update
    void Start()
    {
        line = connect.GetComponent<LineRenderer>();
        line.SetVertexCount(2);
    }

    // Update is called once per frame
    void Update()
    {
        GeometryCreator col1 = obj1.GetComponent<GeometryCreator>();
        GeometryCreator col2 = obj2.GetComponent<GeometryCreator>();
        if (is2D)
        {
            if (isMinimumDistance)
            {
                Vector2 L = new Vector2();
                Vector2 P = new Vector2();
                if (col1.Primitive_2D == GeometryCreator._2Dgeo.Point & col2.Primitive_2D == GeometryCreator._2Dgeo.Point)
                {
                    L = obj1.transform.position;
                    P = obj2.transform.position;
                }
                if (col1.Primitive_2D == GeometryCreator._2Dgeo.Point & col2.Primitive_2D == GeometryCreator._2Dgeo.Ellipse)
                {
                    Vector2 point = obj1.transform.position;
                    Vector2[] T = Minimum_distance_2D.Point_Ellipse(point, obj2);
                    L = T[0];
                    P = T[1];
                }

                if(col1.Primitive_2D == GeometryCreator._2Dgeo.Ellipse & col2.Primitive_2D == GeometryCreator._2Dgeo.Point)
                {
                    Vector2 point = obj2.transform.position;
                    Vector2[] T = Minimum_distance_2D.Point_Ellipse(point, obj1);
                    L = T[0];
                    P = T[1];
                }

                if(col1.Primitive_2D == GeometryCreator._2Dgeo.Ellipse & col2.Primitive_2D == GeometryCreator._2Dgeo.Ellipse)
                {
                    Vector2[] T = Minimum_distance_2D.Ellipse_ellipse(obj1, obj2);
                    L = T[0];
                    P = T[1];
                    float CA = Minimum_distance_2D.Ellipse_ellipse_distance_of_closest_approach(obj1, obj2);
                }

                if(col1.Primitive_2D == GeometryCreator._2Dgeo.Line & col2.Primitive_2D == GeometryCreator._2Dgeo.Superellipse)
                {
                    Vector2[] LP = Minimum_distance_2D.Superellipse_line(obj1, obj2);
                    L = LP[0];
                    P = LP[1];
                }

                if(col1.Primitive_2D == GeometryCreator._2Dgeo.Superellipse & col2.Primitive_2D == GeometryCreator._2Dgeo.Line)
                {
                    Vector2[] LP = Minimum_distance_2D.Superellipse_line(obj2, obj1);
                    L = LP[0];
                    P = LP[1];
                }

                if(col1.Primitive_2D == GeometryCreator._2Dgeo.Convex_Line & col2.Primitive_2D == GeometryCreator._2Dgeo.Line)
                {
                    Vector2[] LP = Minimum_distance_2D.Convex_Line(obj1, obj2);
                    L = LP[0];
                    P = LP[1];
                }

                if(col1.Primitive_2D == GeometryCreator._2Dgeo.Line & col2.Primitive_2D == GeometryCreator._2Dgeo.Convex_Line)
                {
                    Vector2[] LP = Minimum_distance_2D.Convex_Line(obj2, obj1);
                    L = LP[0];
                    P = LP[1];
                }

                if(col1.Primitive_2D == GeometryCreator._2Dgeo.Convex_Circle & col2.Primitive_2D == GeometryCreator._2Dgeo.Circle)
                {
                    Vector2[] LP = Minimum_distance_2D.Convex_Circle(obj1, obj2);
                    L = LP[0];
                    P = LP[1];
                }

                if(col1.Primitive_2D == GeometryCreator._2Dgeo.Circle & col2.Primitive_2D == GeometryCreator._2Dgeo.Convex_Circle)
                {
                    Vector2[] LP = Minimum_distance_2D.Convex_Circle(obj2, obj1);
                    L = LP[0];
                    P = LP[1];
                }

                Vector3 Point_ = obj2.transform.InverseTransformPoint(L);
                Vector3 p_ = obj2.transform.InverseTransformPoint(P);

                if(Point_.sqrMagnitude > p_.sqrMagnitude)
                {
                    line.startColor = Color.green;
                    line.endColor = Color.green;
                }
                if(Point_.sqrMagnitude < p_.sqrMagnitude)
                {
                    line.startColor = Color.red;
                    line.endColor = Color.red;
                }
                
                line.SetPosition (0, L);
                line.SetPosition (1, P);

            }
            else
            {
                switch ((obj1.name, obj2.name))
                {
                    //2D

                    //Point2D-Point2D
                    case ("Point", "Point"):
                        collision = obj1.transform.position == obj2.transform.position;
                        break;

                    //AABB-ABBB 2D
                    case ("AABB(Clone)", "AABB(Clone)"):
                        double length1 = obj1.GetComponent<Renderer>().bounds.extents.x * 2;
                        double height1 = obj1.GetComponent<Renderer>().bounds.extents.y * 2;
                        double length2 = obj2.GetComponent<Renderer>().bounds.extents.x * 2;
                        double height2 = obj2.GetComponent<Renderer>().bounds.extents.y * 2;
                        collision = ProximityQuery2D.AABB_AABB2D(obj1.transform.position, obj2.transform.position, length1, length2, height1, height2);
                        break;
                    //OBB-OBB 2D 
                    case ("OBB(Clone)", "OBB(Clone)"):
                        Renderer rend1 = obj1.GetComponent<Renderer>();
                        Renderer rend2 = obj2.GetComponent<Renderer>();
                        Vector3[] corners1 = { rend1.bounds.max, new Vector3(rend1.bounds.min.x, rend1.bounds.max.y, -1), rend1.bounds.min, new Vector3(rend1.bounds.max.x, rend1.bounds.min.y, -1) };
                        Vector3 nX1 = ((corners1[0] + corners1[1]) / 2) - ((corners1[2] + corners1[3]) / 2);
                        Vector3 nY1 = ((corners1[0] + corners1[3]) / 2) - ((corners1[2] + corners1[1]) / 2);
                        Vector3 normalX1 = nX1 / nX1.magnitude;
                        Vector3 normalY1 = nY1 / nY1.magnitude;
                        Vector3[] normals1 = { normalX1, normalY1 };
                        Vector3[] corners2 = { rend2.bounds.max, new Vector3(rend2.bounds.min.x, rend2.bounds.max.y, -1), rend2.bounds.min, new Vector3(rend2.bounds.max.x, rend2.bounds.min.y, -1) };
                        Vector3 nX2 = ((corners2[0] + corners2[1]) / 2) - ((corners2[2] + corners2[3]) / 2);
                        Vector3 nY2 = ((corners2[0] + corners2[3]) / 2) - ((corners2[2] + corners2[1]) / 2);
                        Vector3 normalX2 = nX2 / nX2.magnitude;
                        Vector3 normalY2 = nY2 / nY2.magnitude;
                        Vector3[] normals2 = { normalX2, normalY2 };
                        collision = ProximityQuery2D.OBB_OBB2D(normals1, normals2, corners1, corners2);
                        break;
                    case ("Ellipse", "Ellipse"):
                        collision = ProximityQuery2D.Ellipse_Ellipse_Caravantes(obj1, obj2);
                        break;
                }
            }
        }
        else
        {
            if (isMinimumDistance)
            {
                Vector3 L3 = new Vector3();
                Vector3 P3 = new Vector3();

                if (col1.Primitive_3D == GeometryCreator._3Dgeo.Point & col2.Primitive_3D == GeometryCreator._3Dgeo.Ellipsoid)
                {
                    Vector3 point = obj1.transform.position;
                    Vector3[] LP = Minimum_distance_3D.point_Ellipsoid(point, obj2);
                    L3 = LP[0];
                    P3 = LP[1];
                }

                if(col1.Primitive_3D == GeometryCreator._3Dgeo.Ellipsoid & col2.Primitive_3D == GeometryCreator._3Dgeo.Point)
                {
                    Vector3 point = obj2.transform.position;
                    Vector3[] LP = Minimum_distance_3D.point_Ellipsoid(point, obj1);
                    L3 = LP[0];
                    P3 = LP[1];
                }

                if(col1.Primitive_3D == GeometryCreator._3Dgeo.Ellipsoid & col2.Primitive_3D == GeometryCreator._3Dgeo.Ellipsoid)
                {
                    Vector3[] T = Minimum_distance_3D.Ellipsoid_ellipsoid(obj1, obj2);
                    L3 = T[0];
                    P3 = T[1];
                    //float CA = Minimum_distance_3D.Ellipsoid_ellipsoid_distance_of_closest_approach(obj1, obj2);
                    //Debug.Log(CA);
                }

                if(col1.Primitive_3D == GeometryCreator._3Dgeo.Superellipsoid & col2.Primitive_3D == GeometryCreator._3Dgeo.Plane)
                {
                    Vector3[] LP = Minimum_distance_3D.Superellipsoid_Plane(obj1, obj2);
                    L3 = LP[0];
                    P3 = LP[1];
                }

                if(col1.Primitive_3D == GeometryCreator._3Dgeo.Plane & col2.Primitive_3D == GeometryCreator._3Dgeo.Superellipsoid)
                {
                    Vector3[] LP = Minimum_distance_3D.Superellipsoid_Plane(obj2, obj1);
                    L3 = LP[0];
                    P3 = LP[1];
                }

                if(col1.Primitive_3D == GeometryCreator._3Dgeo.Convex & col2.Primitive_3D == GeometryCreator._3Dgeo.Plane)
                {
                    Vector3[] T = Minimum_distance_3D.AlmostConvexGeometry_Plane(obj1, obj2);
                    L3 = T[0];
                    P3 = T[1];
                }

                if(col1.Primitive_3D == GeometryCreator._3Dgeo.Plane & col2.Primitive_3D == GeometryCreator._3Dgeo.Convex)
                {
                    Vector3[] T = Minimum_distance_3D.AlmostConvexGeometry_Plane(obj2, obj1);
                    L3 = T[0];
                    P3 = T[1];
                }

                Vector3 Point_ = obj2.transform.InverseTransformPoint(L3);
                Vector3 p_ = obj2.transform.InverseTransformPoint(P3);

                if(Point_.sqrMagnitude > p_.sqrMagnitude)
                {
                    line.startColor = Color.green;
                    line.endColor = Color.green;
                }
                if(Point_.sqrMagnitude < p_.sqrMagnitude)
                {
                    line.startColor = Color.red;
                    line.endColor = Color.red;
                }
                line.SetPosition (0, L3);
                line.SetPosition (1, P3);
            }
            else
            {
                switch ((obj1.name, obj2.name))
                {
                    //3D

                    //Point3D-Point3D
                    case ("Point3D", "Point3D"):
                        collision = obj1.transform.position == obj2.transform.position;
                        break;

                    //Point-Sphere 3D
                    case ("Sphere3D(Clone)", "Point3D(Clone)"):
                    case ("Point3D(Clone)", "Sphere3D(Clone)"):
                        double sphereRadius = 0;
                        Vector3 positionPoint = new Vector3(0, 0, 0);
                        Vector3 positionSphere = new Vector3(0, 0, 0);

                        switch (obj1.name)
                        {
                            case ("Sphere3D(Clone)"):
                                sphereRadius = obj1.GetComponent<Renderer>().bounds.extents.x;
                                positionSphere = obj1.transform.position;
                                positionPoint = obj2.transform.position;
                                break;
                            case ("Point3D(Clone)"):
                                sphereRadius = obj2.GetComponent<Renderer>().bounds.extents.x;
                                positionSphere = obj2.transform.position;
                                positionPoint = obj1.transform.position;
                                break;
                        }
                        collision = ProximityQuery3D.PointSphere3D(positionPoint, positionSphere, sphereRadius);
                        break;

                    //Point-AABB 3D
                    case ("Point3D(Clone)", "AABB3D(Clone)"):
                    case ("AABB3D(Clone)", "Point3D(Clone)"):
                        Vector3 pPoint = new Vector3(0, 0, 0);
                        Vector3 pAABB = new Vector3(0, 0, 0);
                        double len = -1;
                        double wid = -1;
                        double hei = -1;

                        switch (obj1.name)
                        {
                            case ("Point3D(Clone)"):
                                pPoint = obj1.transform.position;
                                pAABB = obj2.transform.position;
                                len = obj2.GetComponent<Renderer>().bounds.extents.x * 2;
                                wid = obj2.GetComponent<Renderer>().bounds.extents.y * 2;
                                hei = obj2.GetComponent<Renderer>().bounds.extents.z * 2;
                                break;
                            case ("AABB3D(Clone)"):
                                pPoint = obj2.transform.position;
                                pAABB = obj1.transform.position;
                                len = obj1.GetComponent<Renderer>().bounds.extents.x * 2;
                                wid = obj1.GetComponent<Renderer>().bounds.extents.y * 2;
                                hei = obj1.GetComponent<Renderer>().bounds.extents.z * 2;
                                break;
                        }
                        collision = ProximityQuery3D.Point_AABB3D(pPoint, pAABB, len, wid, hei);
                        break;

                    //Sphere-AABB 3D
                    case ("Sphere3D(Clone)", "AABB3D(Clone)"):
                    case ("AABB3D(Clone)", "Sphere3D(Clone)"):
                        double sRadius = 0;
                        Vector3 pSphere = new Vector3(0, 0, 0);
                        Vector3 positionAABB = new Vector3(0, 0, 0);
                        double l = -1;
                        double w = -1;
                        double h = -1;

                        switch (obj1.name)
                        {
                            case ("Sphere3D(Clone)"):
                                sRadius = obj1.GetComponent<Renderer>().bounds.extents.x;
                                pSphere = obj1.transform.position;
                                positionAABB = obj2.transform.position;
                                l = obj2.GetComponent<Renderer>().bounds.extents.x * 2;
                                w = obj2.GetComponent<Renderer>().bounds.extents.y * 2;
                                h = obj2.GetComponent<Renderer>().bounds.extents.z * 2;
                                break;
                            case ("AABB3D(Clone)"):
                                sRadius = obj2.GetComponent<Renderer>().bounds.extents.x;
                                pSphere = obj2.transform.position;
                                positionAABB = obj1.transform.position;
                                l = obj1.GetComponent<Renderer>().bounds.extents.x * 2;
                                w = obj1.GetComponent<Renderer>().bounds.extents.y * 2;
                                h = obj1.GetComponent<Renderer>().bounds.extents.z * 2;
                                break;
                        }
                        collision = ProximityQuery3D.Sphere_AABB3D(positionAABB, l, h, w, pSphere, sRadius);
                        break;

                    //Sphere-Sphere 3D
                    case ("Sphere3D(Clone)", "Sphere3D(Clone)"):
                        double sphere1Radius = obj1.GetComponent<Renderer>().bounds.extents.x;
                        double sphere2Radius = obj2.GetComponent<Renderer>().bounds.extents.x;
                        collision = ProximityQuery3D.SphereSphere3D(obj1.transform.position, obj2.transform.position, sphere1Radius, sphere2Radius);
                        break;

                    //AABB-AABB 3D
                    case ("AABB3D(Clone)", "AABB3D(Clone)"):
                        double l1 = obj1.GetComponent<Renderer>().bounds.extents.x * 2;
                        double w1 = obj1.GetComponent<Renderer>().bounds.extents.y * 2;
                        double h1 = obj1.GetComponent<Renderer>().bounds.extents.z * 2;
                        double l2 = obj2.GetComponent<Renderer>().bounds.extents.x * 2;
                        double w2 = obj2.GetComponent<Renderer>().bounds.extents.y * 2;
                        double h2 = obj2.GetComponent<Renderer>().bounds.extents.z * 2;
                        collision = ProximityQuery3D.AABB_AABB3D(obj1.transform.position, obj2.transform.position, l1, l2, w1, w2, h1, h2);
                        break;

                    //OBB-OBB 3D
                    case ("OBB3D(Clone)", "OBB3D(Clone)"):
                        Renderer r1 = obj1.GetComponent<Renderer>();
                        Renderer r2 = obj2.GetComponent<Renderer>();

                        Vector3[] c1 = { r1.bounds.max, new Vector3(r1.bounds.max.x, r1.bounds.min.y, r1.bounds.min.z), new Vector3(r1.bounds.min.x, r1.bounds.max.y, r1.bounds.min.z), new Vector3(r1.bounds.min.x, r1.bounds.min.y, r1.bounds.max.z),
                    r1.bounds.min, new Vector3(r1.bounds.max.x, r1.bounds.max.y, r1.bounds.min.z),new Vector3(r1.bounds.max.x, r1.bounds.min.y, r1.bounds.max.z),new Vector3(r1.bounds.min.x, r1.bounds.max.y, r1.bounds.max.z)  };
                        Vector3[] c2 = { r2.bounds.max, new Vector3(r2.bounds.max.x, r2.bounds.min.y, r2.bounds.min.z), new Vector3(r2.bounds.min.x, r2.bounds.max.y, r2.bounds.min.z), new Vector3(r2.bounds.min.x, r2.bounds.min.y, r2.bounds.max.z),
                    r2.bounds.min, new Vector3(r2.bounds.max.x, r2.bounds.max.y, r2.bounds.min.z),new Vector3(r2.bounds.max.x, r2.bounds.min.y, r2.bounds.max.z),new Vector3(r2.bounds.min.x, r2.bounds.max.y, r2.bounds.max.z)  };

                        Vector3 P10 = (c1[5] + c1[6]) / 2;
                        Vector3 P11 = (c1[0] + c1[2]) / 2;
                        Vector3 P12 = (c1[4] + c1[7]) / 2;
                        Vector3 P13 = (c1[4] + c1[5]) / 2;
                        Vector3 P14 = (c1[4] + c1[6]) / 2;
                        Vector3 P15 = (c1[0] + c1[3]) / 2;

                        Vector3 P20 = (c2[5] + c2[6]) / 2;
                        Vector3 P21 = (c2[0] + c2[2]) / 2;
                        Vector3 P22 = (c2[4] + c2[7]) / 2;
                        Vector3 P23 = (c2[4] + c2[5]) / 2;
                        Vector3 P24 = (c2[4] + c2[6]) / 2;
                        Vector3 P25 = (c2[0] + c2[3]) / 2;

                        Vector3 n11 = P13 - P15;
                        Vector3 n12 = P11 - P14;
                        Vector3 n13 = P10 - P12;

                        Vector3 n21 = P23 - P25;
                        Vector3 n22 = P21 - P24;
                        Vector3 n23 = P20 - P22;

                        Vector3[] n = {n11, n12, n13, n21, n22, n23,
                        Vector3.Cross(n11,n21), Vector3.Cross(n11, n22), Vector3.Cross(n11, n23),
                        Vector3.Cross(n12, n21), Vector3.Cross(n12, n22), Vector3.Cross(n12, n23),
                        Vector3.Cross(n13,n21), Vector3.Cross(n13, n22), Vector3.Cross(n13, n23)};

                        collision = ProximityQuery3D.OBB_OBB3D(n, c1, c2);

                        break;
                    case ("Ellipsoid", "Ellipsoid"):
                        collision = ProximityQuery3D.Ellipsoid_Ellipsoid_Caravantes(obj1, obj2);
                        break;
                    case ("Cylinder", "Cylinder"):
                        collision = ProximityQuery3D.Cylinder_Cylinder_Chittawadigi(obj1, obj2);
                        break;
                    case ("Ellipsoid", "EllipticParaboloid"):
                        collision = ProximityQuery3D.Ellipsoid_EllipticParaboloid_Brozos(obj1, obj2);
                        break;
                    case ("Hyperboloid", "Plane"):
                        collision = ProximityQuery3D.Hyperboloid_Plane_Bektas(obj1, obj2);
                        break;
                }
            }
        }
    }
}